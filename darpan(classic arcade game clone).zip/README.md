# udacity-classic-arcade-game-clone
Project: Classic Arcade Game Clone

## Using

Clone this repo to your desktop, go to `udacity-classic-arcade-game-clone` its directory and run:

```bash
$ python -m SimpleHTTPServer
```

Access and test application, Navigate to

```bash
http://localhost:8000
```
